import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import Stripe from "stripe";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(cors({ origin: process.env.APP_ORIGIN || true }));
app.use(express.json({ limit: "1mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false }));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Bot AI", aiConfigured: Boolean(process.env.OPENAI_API_KEY), billingConfigured: Boolean(process.env.STRIPE_SECRET_KEY) }));

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 8000) return res.status(413).json({ error: "Message is too long." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "AI provider is not configured yet. Add OPENAI_API_KEY in your environment variables." });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are Bot AI, a helpful, clear and friendly AI assistant. Do not claim to be a different product." },
        { role: "user", content: message }
      ], max_tokens: 1200
    });
    res.json({ reply: completion.choices?.[0]?.message?.content || "I couldn't generate a reply. Please try again." });
  } catch (error) {
    console.error("Chat request failed:", error?.message || error);
    res.status(500).json({ error: "The AI request failed. Check server configuration and try again." });
  }
});

app.post("/api/create-checkout-session", async (req, res) => {
  try {
    if (!process.env.STRIPE_SECRET_KEY) return res.status(503).json({ error: "Stripe is not configured yet." });
    const priceId = String(req.body?.priceId || "");
    const allowed = [process.env.STRIPE_PRO_PRICE_ID, process.env.STRIPE_DEVELOPER_PRICE_ID].filter(Boolean);
    if (!allowed.includes(priceId)) return res.status(400).json({ error: "Unknown plan price." });
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.create({
      mode: "subscription", line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.APP_ORIGIN || "http://localhost:3000"}/?billing=success`,
      cancel_url: `${process.env.APP_ORIGIN || "http://localhost:3000"}/?billing=cancelled`
    });
    res.json({ url: session.url });
  } catch (error) {
    console.error("Checkout creation failed:", error?.message || error);
    res.status(500).json({ error: "Couldn't create checkout session." });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Bot AI running on port ${PORT}`));
